import img from "./image.png";
const cardinfo=[
    {
        id:1,
        image:"./image.png",
        category:"Health & Wellness",
        info:"1mg",
        description:"Flat 70% off on prescription medicines",
        expirees:"Expiress: Nov 30, 2021"
    },
    {
        id:2,
        image:{img},
        category:"Health & Wellness",
        info:"1mg",
        description:"Flat 70% off on prescription medicines",
        expirees:"Expiress: Nov 30, 2021"
    },
    {
        id:3,
        image:{img},
        category:"Health & Wellness",
        info:"1mg",
        description:"Flat 70% off on prescription medicines",
        expirees:"Expiress: Nov 30, 2021"
    },
    {
        id:4,
        image:{img},
        category:"Health & Wellness",
        info:"1mg",
        description:"Flat 70% off on prescription medicines",
        expirees:"Expiress: Nov 30, 2021"
    },
    {
        id:5,
        image:{img},
        category:"Health & Wellness",
        info:"1mg",
        description:"Flat 70% off on prescription medicines",
        expirees:"Expiress: Nov 30, 2021"
    },
    {
        id:6,
        image:{img},
        category:"Health & Wellness",
        info:"1mg",
        description:"Flat 70% off on prescription medicines",
        expirees:"Expiress: Nov 30, 2021"
    },
    {
        id:7,
        image:{img},
        category:"Health & Wellness",
        info:"1mg",
        description:"Flat 70% off on prescription medicines",
        expirees:"Expiress: Nov 30, 2021"
    }
];
export default cardinfo;